import React, { useEffect } from 'react';
import { HashRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Layout from './components/Layout';
import LandingPage from './components/LandingPage';
import FormPage from './components/FormPage';

// Helper component to scroll to top on route change
const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const App: React.FC = () => {
  return (
    <Router>
      <ScrollToTop />
      <Layout>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route 
            path="/editor" 
            element={<FormPage title="Join as a Video Editor" type="editor" />} 
          />
          <Route 
            path="/client" 
            element={<FormPage title="Hire a Video Editor" type="client" />} 
          />
        </Routes>
      </Layout>
    </Router>
  );
};

export default App;