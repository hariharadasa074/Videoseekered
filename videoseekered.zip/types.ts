export enum UserType {
  EDITOR = 'EDITOR',
  CLIENT = 'CLIENT'
}

export interface NavItem {
  label: string;
  path: string;
}
