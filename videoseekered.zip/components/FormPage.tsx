import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, CheckCircle, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface FormPageProps {
  title: string;
  type: 'editor' | 'client';
}

const FormPage: React.FC<FormPageProps> = ({ title, type }) => {
  const navigate = useNavigate();
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);

    const formData = new FormData(e.currentTarget);
    const payload = Object.fromEntries(formData.entries());

    try {
        // Send data to FormSubmit.co using the provided email
        const response = await fetch("https://formsubmit.co/ajax/hdasa5686@gmail.com", {
            method: "POST",
            headers: { 
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                ...payload,
                _subject: `New Videoseekered Submission: ${title}`,
                _template: 'table',
                _captcha: 'false'
            })
        });

        if (response.ok) {
            setIsSubmitted(true);
            window.scrollTo({ top: 0, behavior: 'smooth' });
        } else {
            console.error("Submission failed");
            alert("Something went wrong. Please try again.");
        }
    } catch (error) {
        console.error("Error:", error);
        alert("Network error. Please check your connection.");
    } finally {
        setIsLoading(false);
    }
  };

  const successMessage = type === 'editor' 
    ? "Your details have been successfully submitted!" 
    : "Your request has been successfully submitted!";

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 min-h-[80vh]">
      <button 
        onClick={() => navigate('/')}
        className="flex items-center text-gray-400 hover:text-white transition-colors mb-8 group"
      >
        <ArrowLeft className="w-4 h-4 mr-2 group-hover:-translate-x-1 transition-transform" />
        Back to Home
      </button>

      <AnimatePresence mode="wait">
        {!isSubmitted ? (
          <motion.div
            key="form"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white/5 border border-white/10 rounded-2xl p-1 md:p-8 backdrop-blur-sm"
          >
            <h2 className="text-3xl font-bold text-white mb-6 text-center md:text-left pl-4 border-l-4 border-brand-purple">
              {title}
            </h2>
            
            <div className="bg-white rounded-xl overflow-hidden relative shadow-inner">
              {isLoading && (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-50/90 text-gray-500 z-10 backdrop-blur-sm">
                  <Loader2 className="w-8 h-8 animate-spin mb-2 text-brand-blue" />
                  <p>Sending...</p>
                </div>
              )}
              
              <div className="w-full h-full p-8 bg-white text-gray-800">
                <div className="w-full h-2 bg-brand-purple mb-8 rounded-full opacity-50"></div>
                
                <form onSubmit={handleSubmit} className="space-y-6 max-w-2xl mx-auto">
                  {/* Honeypot for spam bots */}
                  <input type="text" name="_honey" style={{ display: 'none' }} />
                  
                  <div className="space-y-2">
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                      Email Address <span className="text-red-500">*</span>
                    </label>
                    <input 
                      id="email" 
                      name="email" 
                      type="email" 
                      required
                      placeholder="your@email.com" 
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-purple focus:border-transparent outline-none transition-all" 
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                      Full Name <span className="text-red-500">*</span>
                    </label>
                    <input 
                      id="name" 
                      name="name" 
                      type="text" 
                      required
                      placeholder="John Doe" 
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-purple focus:border-transparent outline-none transition-all" 
                    />
                  </div>
                  
                  {type === 'editor' ? (
                     <div className="space-y-2">
                     <label htmlFor="portfolio" className="block text-sm font-medium text-gray-700">
                       Portfolio Link <span className="text-red-500">*</span>
                     </label>
                     <input 
                        id="portfolio" 
                        name="portfolio" 
                        type="url" 
                        required
                        placeholder="https://vimeo.com/..." 
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-purple focus:border-transparent outline-none transition-all" 
                     />
                   </div>
                  ) : (
                    <div className="space-y-2">
                    <label htmlFor="project_details" className="block text-sm font-medium text-gray-700">
                      Project Description <span className="text-red-500">*</span>
                    </label>
                    <textarea 
                        id="project_details" 
                        name="project_details" 
                        rows={4} 
                        required
                        placeholder="Describe what you need..." 
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-purple focus:border-transparent outline-none transition-all" 
                    />
                  </div>
                  )}
                  
                  <div className="pt-4 pb-8">
                     <button 
                        type="submit"
                        disabled={isLoading}
                        className="bg-brand-purple hover:bg-brand-blue text-white font-medium py-2 px-6 rounded-md shadow-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                     >
                        {isLoading ? 'Submitting...' : 'Submit Application'}
                     </button>
                     <p className="text-xs text-gray-400 mt-2">
                        By submitting, you agree to share your details with Videoseekered.
                     </p>
                  </div>
                </form>
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="success"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col items-center justify-center py-20 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-sm text-center px-4"
          >
            <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mb-6 text-green-400">
               <CheckCircle className="w-10 h-10" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-2">Success!</h3>
            <p className="text-lg text-gray-300 mb-8">{successMessage}</p>
            <button
              onClick={() => navigate('/')}
              className="px-8 py-3 bg-white text-brand-dark font-semibold rounded-full hover:bg-gray-200 transition-colors"
            >
              Back to Home
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default FormPage;