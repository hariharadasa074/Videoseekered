import React from 'react';
import { Link } from 'react-router-dom';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  // Custom SVG Data URI recreating the Videoseeker logo
  // Design: Blue circle background, Magnifying glass with Eye inside
  const logoSrc = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='50' cy='50' r='50' fill='%230033a0'/%3E%3Cpath d='M66 66 L82 82' stroke='white' stroke-width='10' stroke-linecap='round'/%3E%3Ccircle cx='46' cy='46' r='26' stroke='white' stroke-width='6' fill='%23e2d5c3'/%3E%3Cpath d='M26 46 Q46 26 66 46 Q46 66 26 46 Z' fill='white'/%3E%3Ccircle cx='46' cy='46' r='9' fill='%230033a0'/%3E%3Ccircle cx='46' cy='46' r='3' fill='white'/%3E%3C/svg%3E";

  return (
    <div className="min-h-screen flex flex-col bg-brand-dark text-white selection:bg-brand-purple selection:text-white overflow-x-hidden">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 backdrop-blur-md bg-brand-dark/80 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-3 group">
            <img 
              src={logoSrc} 
              alt="Videoseekered Logo" 
              className="w-10 h-10 rounded-full shadow-lg group-hover:shadow-[0_0_20px_rgba(0,51,160,0.6)] transition-all duration-300"
            />
            <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-400">
              Videoseekered
            </span>
          </Link>
          <nav className="hidden md:flex items-center space-x-8 text-sm font-medium text-gray-400">
            <Link to="/" className="hover:text-white transition-colors">Home</Link>
            <span className="hover:text-white transition-colors cursor-not-allowed opacity-50">About</span>
            <span className="hover:text-white transition-colors cursor-not-allowed opacity-50">Contact</span>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow pt-16">
        {children}
      </main>

      {/* Footer */}
      <footer className="border-t border-white/10 py-8 bg-brand-dark">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} Videoseekered. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;